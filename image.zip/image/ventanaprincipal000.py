# -*- coding: utf-8 -*-


from PySide import QtCore, QtGui

class Ui_Ventana(object):

    def setupUi(self, Window):
        Window.setObjectName("Window")
        Window.resize(400, 350)
        self.table_categoria= QtGui.QTableView(Window)
        self.table_categoria.setGeometry(QtCore.QRect(20,50,100,150))
        self.table_categoria.setObjectName("table_producto")
        self.table_categoria.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.table_categoria.setAlternatingRowColors(True)
        self.table_categoria.setSortingEnabled(True)
	
	self.button1= QtGui.QPushButton(Window)
        self.button1.setGeometry(QtCore.QRect(330,200,60,50))
        self.button1.setObjectName("button1")
	
	self.button2 = QtGui.QPushButton(Window)
        self.button2.setGeometry(QtCore.QRect(330,250,60,50))
        self.button2.setObjectName("button2")
        
        
	self.label = QtGui.QLabel(Window)
        self.label.setGeometry(QtCore.QRect(30,20,200,16))
        self.label.setObjectName("label")

        self.label2 = QtGui.QLabel(Window)
        self.label2.setGeometry(QtCore.QRect(130,50,200,16))
        self.label2.setObjectName("label2")

	self.label3 = QtGui.QLabel(Window)
        self.label3.setGeometry(QtCore.QRect(20,210,200,16))
        self.label3.setObjectName("label3")

        self.retranslateUi(Window)
        QtCore.QMetaObject.connectSlotsByName(Window)
        
        

    def retranslateUi(self, Window):
        Window.setWindowTitle(QtGui.QApplication.translate("Window", "Recetas", None, QtGui.QApplication.UnicodeUTF8))
        self.button1.setText(QtGui.QApplication.translate("Window", "Editar", None, QtGui.QApplication.UnicodeUTF8))
	self.button2.setText(QtGui.QApplication.translate("Window", "Guardar", None, QtGui.QApplication.UnicodeUTF8))
	self.label.setText(QtGui.QApplication.translate("Window", "Nombre de Receta", None, QtGui.QApplication.UnicodeUTF8))
        self.label2.setText(QtGui.QApplication.translate("Window", "Ingredientes: ", None, QtGui.QApplication.UnicodeUTF8))
	self.label3.setText(QtGui.QApplication.translate("Window", "Preparación: ", None, QtGui.QApplication.UnicodeUTF8))
