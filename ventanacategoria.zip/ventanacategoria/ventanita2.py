#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

from PySide import QtGui, QtCore
import base
from formulario2 import Ui_Ventana


class Formu2(QtGui.QDialog):

    def __init__(self,parent=None, id_categoria=None, nombre= None):
        QtGui.QDialog.__init__(self,parent)
        self.ui = Ui_Ventana()
        self.ui.setupUi(self)
        self.show()

        self.id_categoria = id_categoria
        self.nombre = nombre
        datos = base.datos_categoria(nombre)
        
        if nombre is None:
            self.ui.pushButton.clicked.connect(self.agregar)
        else:

			datos = base.datos_categoria(nombre)

			self.ui.search_box1.setText(str(datos[0]))
			self.ui.search_box2.setText(datos[1])
			self.ui.search_box3.setText(datos[2])
			self.id_ =(str(datos[0]))
			
			self.ui.button1.clicked.connect(self.actualizar)
		
	self.ui.button2.clicked.connect(self.cancel)
        


    def actualizar(self):
        # sin modificar id_categoria
        antiguo = self.id_
        
        nid = self.ui.search_box1.text()
        nid_ca = str(nid)
        nombre = self.ui.search_box2.text()
        ndescripcion =self.ui.search_box3.text()
        actualizar = base.actualizar_categoria(nid_ca,nombre,ndescripcion,antiguo)
        
        if actualizar:
			self.reject()
        else:
			self.ui.errorMessageDialog = QtGui.QErrorMessage(self)
			self.ui.errorMessageDialog.showMessage("Hubo un problema al intentar editar ")


                 		
    def cancel(self):
        self.reject()







