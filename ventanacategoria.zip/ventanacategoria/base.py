#!/usr/bin/python
import sqlite3

def conectar():
    con = sqlite3.connect('base12.db')
    con.row_factory = sqlite3.Row
    return con


def obtener_categoria():
    con = conectar()
    c = con.cursor()
    query = "SELECT nombre FROM categorias GROUP BY nombre"
    resultado= c.execute(query)
    categoria = resultado.fetchall()
    con.close()
    return categoria


def obtener_cantidad():
    con = conectar()
    c = con.cursor()
    query = """SELECT count(b.fk_id_categoria) as 'cantidad'FROM categorias a, recetas b WHERE b.fk_id_categoria = a.id_categoria GROUP BY a.nombre"""
    result = c.execute(query)
    cantidad = result.fetchall()
    con.close()
    return cantidad 


def id_categoria(nombre):
    con = conectar()
    c = con.cursor()
    query = "SELECT id_categoria FROM categorias WHERE nombre = ?"
    resultado= c.execute(query, [nombre])
    dato = resultado.fetchone()
    con.close()
    return dato

def datos_categoria(nombre):
    con = conectar()
    c = con.cursor()
    query = "SELECT * FROM categorias WHERE nombre = ?"
    resultado= c.execute(query, [nombre])
    datos = resultado.fetchone()
    con.close()
    return datos


def nuevo_categoria(id_categoria,nombre,descripcion):
    exito = False
    con = conectar()
    c = con.cursor()
    valores = [id_categoria, nombre, descripcion]
    query = "INSERT INTO categorias (id_categoria, nombre, descripcion) VALUES (?, ?, ?)"
    try:
        resultado = c.execute(query,valores)
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
       # print e.args[0]
    con.close()
    return exito

def actualizar_categoria(nid_ca,nombre,ndescipcion,antiguo):
    exito = False
    con = conectar()
    c = con.cursor()
    c.execute("UPDATE categorias SET id_categoria =?, nombre=?, descripcion=? WHERE id_categoria=? ",(nid_ca,nombre,ndescipcion,antiguo,))
    con.commit()
    con.close()
    return True

def delete(id_categoria):
    exito = False
    con = conectar()
    c = con.cursor()
    query = "DELETE FROM recetas WHERE fk_id_categoria = ?"
    try:
        resultado = c.execute(query, [id_categoria])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print ("Error:"), e.args[0]
    con.close()
    return exito

def delete_categoria(id_catego):
    exito = False
    con = conectar()
    c = con.cursor()
    query = "DELETE FROM categorias WHERE id_categoria = ?"
    try:
        resultado = c.execute(query, [id_catego])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print ("Error:"), e.args[0]
    con.close()
    return exito

