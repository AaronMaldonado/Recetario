# -*- coding: utf-8 -*-


    
from PySide import QtCore, QtGui

class Ui_Ventana(object):

    def setupUi(self, Window):
        Window.setObjectName("Window")
        Window.resize(390,280)
        self.button1= QtGui.QPushButton(Window)
        self.button1.setGeometry(QtCore.QRect(100,180,70,50))
        self.button1.setObjectName("button1")
        
        self.button2= QtGui.QPushButton(Window)
        self.button2.setGeometry(QtCore.QRect(210,180,70,50))
        self.button2.setObjectName("button2")
	
	

        self.search_box1 = QtGui.QLineEdit(Window)
        self.search_box1.setGeometry(QtCore.QRect(130,50,230,25))
        self.search_box1.setObjectName("search_box1")
        self.search_box1.setEnabled(False)     
        self.label1 = QtGui.QLabel(Window)
        self.label1.setGeometry(QtCore.QRect(38,40,90,35))
        self.label1.setObjectName("label")
	

        self.search_box2 = QtGui.QLineEdit(Window)
        self.search_box2.setGeometry(QtCore.QRect(130,90,230, 25))
        self.search_box2.setObjectName("search_box2")
       
        self.label2 = QtGui.QLabel(Window)
        self.label2.setGeometry(QtCore.QRect(38,80,80, 35))
        self.label2.setObjectName("label")
	
        self.search_box3 = QtGui.QLineEdit(Window)
        self.search_box3.setGeometry(QtCore.QRect(130,130,230, 25))
        self.search_box3.setObjectName("search_box3")
        
        self.label3 = QtGui.QLabel(Window)
        self.label3.setGeometry(QtCore.QRect(38,120,80, 35))
        self.label3.setObjectName("label")
        

        self.retranslateUi(Window)
        QtCore.QMetaObject.connectSlotsByName(Window)
        
        

    def retranslateUi(self, Window):
        Window.setWindowTitle(QtGui.QApplication.translate("Window", "Formulario", None, QtGui.QApplication.UnicodeUTF8))
        self.button1.setText(QtGui.QApplication.translate("Window", "Agregar", None, QtGui.QApplication.UnicodeUTF8))
        self.button2.setText(QtGui.QApplication.translate("Window", "Salir", None, QtGui.QApplication.UnicodeUTF8))
        self.label1.setText(QtGui.QApplication.translate("Window", "id_categoria  :", None, QtGui.QApplication.UnicodeUTF8))
        self.label2.setText(QtGui.QApplication.translate("Window", "Nombre  :", None, QtGui.QApplication.UnicodeUTF8))
        self.label3.setText(QtGui.QApplication.translate("Window", "Descripcion:", None, QtGui.QApplication.UnicodeUTF8))
	
	
