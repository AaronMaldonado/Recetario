#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import base
import ventanita
import ventanita2
from PySide import QtGui, QtCore
from ventanaprincipal import Ui_Ventana

class main(QtGui.QWidget):

    def __init__(self):
        super(main, self).__init__()
        self.ui = Ui_Ventana()
        self.ui.setupUi(self)
        self.cargar_categoria()
        self.set_button()
        self.show()


    def cargar_categoria(self, categoria = None, cantidad = None):

        if categoria is None and cantidad is None:
         	categoria = base.obtener_categoria()
         	cantidad = base.obtener_cantidad()

        #Creamos el modelo asociado a la tabla
        self.model = QtGui.QStandardItemModel(len(categoria),2)
        self.model.setHorizontalHeaderItem(0, QtGui.QStandardItem(u"Categoria"))
        self.model.setHorizontalHeaderItem(1, QtGui.QStandardItem(u"Cantidad"))

        r = 0
        for row in categoria:
            index = self.model.index(r, 0, QtCore.QModelIndex());
            self.model.setData(index, row['nombre'])
            r = r+1

        j = 0
        for row in cantidad:
            index = self.model.index(j, 1, QtCore.QModelIndex());
            self.model.setData(index, row['cantidad'])
            j = j+1

        self.ui.table_categoria.setModel(self.model)

        self.ui.table_categoria.setColumnWidth(0,255)
        self.ui.table_categoria.setColumnWidth(1,125)

    def set_button(self):
        self.ui.button2.clicked.connect(self.e_formulario)
        #self.ui.button1.clicked.connect(self.show_add)
        self.ui.button3.clicked.connect(self.show_edit_form)
        #self.ui.button3.clicked.connect(self.show_add)
        self.ui.button4.clicked.connect(self.eliminar)

    def e_formulario(self):
        formu = ventanita.Formu(self)
    
    def show_add(self):
		#print "Abre ventana para agregar"
		edita_categoria = ventanita2.Formu2(self)
		edita_categoria.rejected.connect(self.cargar_categoria)
		edita_categoria.exec_()

    def show_edit_form(self):
        model = self.ui.table_categoria.model()
        index = self.ui.table_categoria.currentIndex()
        
        if index.row() == -1: #No se ha seleccionado una fila
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage("Debe seleccionar una fila")

            return False
        else:
            nombre =str(model.index(index.row(), 0, QtCore.QModelIndex()).data())
            id_categoria = base.id_categoria(nombre)
            formu2 = ventanita2.Formu2(self,id_categoria,nombre)
            formu2.rejected.connect(self.cargar_categoria)
            formu2.exec_()
            return True

    def eliminar(self):
           model = self.ui.table_categoria.model()
           index = str(self.ui.table_categoria.currentIndex())
           
           if index.row() == -1: #No se ha seleccionado una fila
              self.errorMessageDialog = QtGui.QErrorMessage(self)
              self.errorMessageDialog.showMessage("Debe seleccionar una fila")
              return False
            
           else:

            nombre =str(model.index(index.row(), 0, QtCore.QModelIndex()).data())
            print (nombre)
            datos = base.datos_categoria(nombre)
            for dato in datos:
                id_ = str(datos[0])
            id_categoria = id_
            eliminar_recetas = base.delete(id_categoria)
            print("holi")
            if eliminar_recetas:
                print("aqui")
                eliminar_categoria = base.delete_categoria(id_categoria)
                self.errorMessageDialog = QtGui.QErrorMessage(self)
                self.errorMessageDialog.showMessage("Se a eliminado categoria")
            else:
                self.errorMessageDialog = QtGui.QErrorMessage(self)
                self.errorMessageDialog.showMessage("No se a podido eliminar registro")
                
            
            
            


def run():
    app = QtGui.QApplication(sys.argv)
    ma = main()
    sys.exit(app.exec_())

if __name__ == '__main__':
    run()
