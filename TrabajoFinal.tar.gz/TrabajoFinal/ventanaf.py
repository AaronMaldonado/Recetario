#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

from PySide import QtGui, QtCore
import controller
from formulario3 import Ui_Ventana


class Formu2(QtGui.QDialog):
	
	
    def __init__(self,parent=None, id_categoria=None, id_paises=None):
        QtGui.QDialog.__init__(self,parent)
        self.ui = Ui_Ventana()
        self.ui.setupUi(self)
        self.show()
        self.cargar_categorias()
        self.cargar_paises()
        
        
        if id_categoria is None and id_paises is None:
		self.ui.button1.clicked.connect(self.datos)
		
        self.ui.button2.clicked.connect(self.cancel)
    
        
        
    def cargar_categorias(self):
        categorias = controller.obtener_categorias()
        for categoria in categorias:
            self.ui.combo_categoria.addItem(categoria["nombre"], categoria["id_categoria"])  
        self.ui.combo_categoria.activated[str].connect(self.datos) 
            
    def cargar_paises(self):
	paises = controller.obtener_paises()
	for pais in paises:
	    self.ui.combo_paises.addItem(pais["nombre"], pais["id_pais"])
	self.ui.combo_paises.activated[str].connect(self.datos) 
	    
    def datos(self):
        id_categoria = self.ui.combo_categoria.itemData(self.ui.combo_categoria.currentIndex())
	print("categoria", id_categoria)

        if id_categoria:
		print("aqui")
		id_paises = self.ui.combo_paises.itemData(self.ui.combo_paises.currentIndex())
		print("id _ pais", id_paises)

	
		id_recetas = self.ui.search_box.text()
		nombre = self.ui.search_box1.text()
		descripcion = self.ui.search_box2.text()
		preparacion = self.ui.TextEdit1.toPlainText()
		ingredientes = self.ui.TextEdit2.toPlainText()
		nuevo = controller.nueva_receta(id_recetas, nombre, descripcion, preparacion, ingredientes, id_categoria, id_recetas)
	
		
	if nuevo:
            self.reject() #Cerramos y esto cargara nuevamente la grilla
       # else:
        #    self.errorMessageDialog = QtGui.QErrorMessage(self)
         #   self.errorMessageDialog.showMessage("No se a podido crear el nuevo producto")
		
    def cancel(self):
        self.reject()
