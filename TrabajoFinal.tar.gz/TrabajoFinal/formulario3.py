# -*- coding: utf-8 -*-


from PySide import QtCore, QtGui

class Ui_Ventana(object):

    def setupUi(self, Formu2):
        Formu2.setObjectName("Formu")
        Formu2.resize(500,700)
        
        self.label = QtGui.QLabel(Formu2)
        self.label.setGeometry(QtCore.QRect(30,15,300, 16))
        self.label.setObjectName("label")
        
        #categoria
        self.label1 = QtGui.QLabel(Formu2)
        self.label1.setGeometry(QtCore.QRect(80,45,300, 16))
        self.label1.setObjectName("label")
        
        self.combo_categoria = QtGui.QComboBox(Formu2)
        self.combo_categoria.setGeometry(QtCore.QRect(50,70, 140, 25))
        self.combo_categoria.setObjectName("combo_marca ")
        
        #paises
        self.label2 = QtGui.QLabel(Formu2)
        self.label2.setGeometry(QtCore.QRect(300,45,300, 16))
        self.label2.setObjectName("label")
        
        self.combo_paises = QtGui.QComboBox(Formu2)
        self.combo_paises.setGeometry(QtCore.QRect(250,70, 140, 25))
        self.combo_paises.setObjectName("combo_marca")
        
        #id
        self.label3 = QtGui.QLabel(Formu2)
        self.label3.setGeometry(QtCore.QRect(170,110,300, 16))
        self.label3.setObjectName("label")
        
        self.search_box = QtGui.QLineEdit(Formu2)
        self.search_box.setGeometry(QtCore.QRect(130, 130, 200, 25))
        self.search_box.setObjectName("search_box")
        
        #nombre
        self.label4 = QtGui.QLabel(Formu2)
        self.label4.setGeometry(QtCore.QRect(170,170,300, 16))
        self.label4.setObjectName("label")
        
        self.search_box1 = QtGui.QLineEdit(Formu2)
        self.search_box1.setGeometry(QtCore.QRect(130, 190, 200, 25))
        self.search_box1.setObjectName("search_box")
        
        #descripcion
        self.label5 = QtGui.QLabel(Formu2)
        self.label5.setGeometry(QtCore.QRect(170,230,300, 16))
        self.label5.setObjectName("label")
        
        self.search_box2 = QtGui.QLineEdit(Formu2)
        self.search_box2.setGeometry(QtCore.QRect(130, 250, 200, 25))
        self.search_box2.setObjectName("search_box")
        
        #preparacion
        self.label6 = QtGui.QLabel(Formu2)
        self.label6.setGeometry(QtCore.QRect(170,290,300, 16))
        self.label6.setObjectName("label")
        
        self.TextEdit1 = QtGui.QTextEdit(Formu2)
        self.TextEdit1.setGeometry(QtCore.QRect(60,310,390,110))
       
        
        
        #Ingredientes
        self.label7 = QtGui.QLabel(Formu2)
        self.label7.setGeometry(QtCore.QRect(170,440,300, 16))
        self.label7.setObjectName("label")

        self.TextEdit2 = QtGui.QTextEdit(Formu2)
        self.TextEdit2.setGeometry(QtCore.QRect(60,460,390,110))
        
        #guardar
        self.button1= QtGui.QPushButton(Formu2)
        self.button1.setGeometry(QtCore.QRect(120,600,100,25))
        self.button1.setObjectName("button1")
        
        #salir
        self.button2= QtGui.QPushButton(Formu2)
        self.button2.setGeometry(QtCore.QRect(300,600,100,25))
        self.button2.setObjectName("button1")
        
        
        self.retranslateUi(Formu2)
        QtCore.QMetaObject.connectSlotsByName(Formu2)
        
    def retranslateUi(self,Formu2):
        Formu2.setWindowTitle(QtGui.QApplication.translate("Window", "Ventana", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Formu", "Formulario de ingreso", None, QtGui.QApplication.UnicodeUTF8))
        self.label1.setText(QtGui.QApplication.translate("Formu", "Categoria", None, QtGui.QApplication.UnicodeUTF8))
        self.label2.setText(QtGui.QApplication.translate("Formu", "Pais", None, QtGui.QApplication.UnicodeUTF8))
        self.label3.setText(QtGui.QApplication.translate("Formu", "Id de la receta", None, QtGui.QApplication.UnicodeUTF8))
        self.label4.setText(QtGui.QApplication.translate("Formu", "Nombre de la receta", None, QtGui.QApplication.UnicodeUTF8))
        self.label5.setText(QtGui.QApplication.translate("Formu", "Descripcion de la receta", None, QtGui.QApplication.UnicodeUTF8))
        self.label6.setText(QtGui.QApplication.translate("Formu", "Preparacion de la receta", None, QtGui.QApplication.UnicodeUTF8))
        self.label7.setText(QtGui.QApplication.translate("Formu", "Ingredientes de la receta", None, QtGui.QApplication.UnicodeUTF8))
        self.search_box.setPlaceholderText(QtGui.QApplication.translate("Formu", "Ingrese el id", None, QtGui.QApplication.UnicodeUTF8))
        self.search_box1.setPlaceholderText(QtGui.QApplication.translate("Formu", "Ingrese el nombre", None, QtGui.QApplication.UnicodeUTF8))
        self.search_box2.setPlaceholderText(QtGui.QApplication.translate("Formu", "Ingrese la descripcion", None, QtGui.QApplication.UnicodeUTF8))
        self.button1.setText(QtGui.QApplication.translate("Formu", "Guardar", None, QtGui.QApplication.UnicodeUTF8))
        self.button2.setText(QtGui.QApplication.translate("Formu", "Salir", None, QtGui.QApplication.UnicodeUTF8))
	
