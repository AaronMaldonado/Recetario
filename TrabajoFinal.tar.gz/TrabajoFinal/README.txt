Trabajo Final : Recetario Cocina 
Ingregrantes:
	Asencio Graciela
	Bello Patricia
	Maldonado Aarón
	Navarro Claudia
	Ramirez Carolina
Funcionamiento del programa:
La ventana principal del programa es main.py ,la cual abre las categorias existentes
para las recetas y la cantidad de recetas por categoria , en la cual 
exiten los botones Mostrar categoria, editar,agregar
y eliminar , estos trabajan para categoria,para poder editar una categoria se 
selecciona una fila y se presiona editar aqui se hacen los cambios que se desean y 
se presiona agregar, luego se cierra el programa se vuelve a abrir y las categorias
estaran actualizadas en la grilla, para agregar una nueva categoria se escriben
el id, el nombre y la descripcion y se presiona agregar, para que se vea la actualizacion
hay que cerrar y volver a abrir el programa.Para eliminar se selecciona una fila
y se presiona eliminar.
Cuando se presiona mostrar categoria se mostraran las recetas y su pais de origen,
si se selecciona una fila y se presiona ver receta se abrira una ventana 
en donde apareceran los ingredientes y la preparacion de la receta elegida y en donde
se podran editar y guardar cambios de las recetas ya existentes.
Para eliminar una receta se selecciona la fila y se presiona eliminar.
Para agregar una receta se presiona agregar y aparecera un formulario donde se debe
elegir la categoria a la que pertenecera y el pais de origen de la receta ,luego se
rellenan los campos que se piden y se agrega , para que se vea en la grilla 
hay que cerrar y volver a abrir el programa, pero no se actualiza la categoria en donde
se agrego dicha receta, al unir las ventanas trabajadas por separado por el grupo
no funciona correctamente el agregar pero si funciona en la ventana individual 
main1.py .

