#!/usr/bin/python
# -*- coding: utf-8 -*-

import sqlite3

def connect():
    con = sqlite3.connect('base12.db')
    con.row_factory = sqlite3.Row
    return con

def get_recetas(id_categoria):
    con = connect()
    c = con.cursor()
    query = """SELECT nombre, id_receta FROM recetas Where fk_id_categoria =?"""
    result = c.execute(query ,[id_categoria])
    recetas = result.fetchall()
    con.close()
    return recetas

def get_recetas_(id_categoria):
    con = connect()
    c = con.cursor()
    query = """SELECT recetas.id_receta ,recetas.nombre , paises.nombre FROM recetas, paises Where fk_id_categoria =? and fk_id_pais = id_pais"""
    result = c.execute(query ,[id_categoria])
    recetas = result.fetchall()
    con.close()
    return recetas


    
def obtener_categorias():
    con = connect()
    c = con.cursor()
    query = "SELECT id_categoria, nombre FROM categorias"
    result= c.execute(query)
    categorias = result.fetchall()
    con.close()
    return categorias
    
def obtener_paises():
    con = connect()
    c = con.cursor()
    query = "SELECT id_pais, nombre FROM paises"
    result= c.execute(query)
    paises = result.fetchall()
    con.close()
    return paises

def nueva_receta(id_receta, nombre, descripcion, preparacion, ingredientes, id_categoria, id_pais):
    exito = False
    con = connect()
    c = con.cursor()
    valores = [id_receta, nombre, descripcion, preparacion, ingredientes, id_categoria, id_pais]
    query = "INSERT INTO recetas (id_receta, nombre, descripcion, preparacion, ingredientes, fk_id_categoria, fk_id_pais) VALUES (?, ?, ?, ?, ?, ?, ?)"
    try:
        result = c.execute(query,valores)
        con.commit()
	exito = True
    except sqlite3.Error as e:
        exito = False
    	print "Error:", e.args[0]
    con.close()
    return exito


def delete(id_receta):
    exito = False
    con = connect()
    c = con.cursor()
    query = "DELETE  FROM recetas  WHERE id_receta = ?"
    try:
        resultado = c.execute(query, [id_receta])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print "Error:", e.args[0]
    con.close()
    return exito
