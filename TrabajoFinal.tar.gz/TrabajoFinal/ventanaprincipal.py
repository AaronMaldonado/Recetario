# -*- coding: utf-8 -*-


    
from PySide import QtCore, QtGui

class Ui_Ventana(object):

    def setupUi(self, Window):
        Window.setObjectName("Window")
        Window.resize(650, 350)
        
        # tamaño y tipo de letra 
        font = QtGui.QFont()
        font.setFamily(u"DejaVu Sans")
        font.setPointSize(18)
        font.bold()
        font.italic()
        
        self.table_categoria= QtGui.QTableView(Window)
        self.table_categoria.setGeometry(QtCore.QRect(20,70,400,240))
        self.table_categoria.setObjectName("table_producto")
        self.table_categoria.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.table_categoria.setAlternatingRowColors(True)
        self.table_categoria.setSortingEnabled(True)
	#self.button0= QtGui.QPushButton(Window)
     #   self.button0.setGeometry(QtCore.QRect(450,20,150,50))
     #   self.button0.setObjectName("button0")
        self.button1 = QtGui.QPushButton(Window)
        self.button1.setGeometry(QtCore.QRect(450,70,150,50))
        self.button1.setObjectName("button1")
        
        self.button2 = QtGui.QPushButton(Window)
        self.button2.setGeometry(QtCore.QRect(450,130,150,50))
        self.button2.setObjectName("button2")  
        self.button3= QtGui.QPushButton(Window)
        self.button3.setGeometry(QtCore.QRect(450,190,150,50))
        self.button3.setObjectName("button3")
        self.button4 = QtGui.QPushButton(Window)
        self.button4.setGeometry(QtCore.QRect(450,250,150,50))
        self.button4.setObjectName("button4")  
        self.label = QtGui.QLabel(Window)
        self.label.setGeometry(QtCore.QRect(30,30,210,30))
        self.label.setObjectName("label")
        self.label.setFont(font)
        self.retranslateUi(Window)
        QtCore.QMetaObject.connectSlotsByName(Window)
        
        

    def retranslateUi(self, Window):
        Window.setWindowTitle(QtGui.QApplication.translate("Window", "Ventana", None, QtGui.QApplication.UnicodeUTF8))
      #  self.button0.setText(QtGui.QApplication.translate("Window", "Mostrar Categoria", None, QtGui.QApplication.UnicodeUTF8))
        self.button1.setText(QtGui.QApplication.translate("Window", "Mostrar Categoria", None, QtGui.QApplication.UnicodeUTF8))
        self.button2.setText(QtGui.QApplication.translate("Window", "Agregar Categoria", None, QtGui.QApplication.UnicodeUTF8))
        self.button3.setText(QtGui.QApplication.translate("Window", "Editar Categoria", None, QtGui.QApplication.UnicodeUTF8))
        self.button4.setText(QtGui.QApplication.translate("Window", "Eliminar Categoria", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Window", "Recetario", None, QtGui.QApplication.UnicodeUTF8))
