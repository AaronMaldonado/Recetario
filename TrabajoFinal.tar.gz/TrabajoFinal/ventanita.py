#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

from PySide import QtGui, QtCore
import base
from formulario import Ui_Ventana


class Formu(QtGui.QDialog):

    def __init__(self,parent=None):
        QtGui.QDialog.__init__(self,parent)
        self.ui = Ui_Ventana()
        self.ui.setupUi(self)
        self.set_button()    
        self.show()

    def nueva_categoria(self):
        id_categoria = self.ui.search_box1.text()
        nombre = self.ui.search_box2.text()
        descripcion = self.ui.search_box3.text()  
        nuevo = base.nuevo_categoria(id_categoria, nombre, descripcion)
		
        if nuevo:
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage("Se a añadito correctamente la categoria")
        else:
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage("No se a podido crear el nuevo producto")

    def set_button(self):
        self.ui.button1.clicked.connect(self.nueva_categoria)
        self.ui.button2.clicked.connect(self.cancel)
	
		
    def cancel(self):
        self.reject()

         
            

