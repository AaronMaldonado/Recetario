#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import controller
import ventana

from PySide import QtGui, QtCore
from ventanaprincipal import Ui_Ventana


class main(QtGui.QWidget):

    def __init__(self):
        super(main, self).__init__()
        self.ui = Ui_Ventana()
        self.ui.setupUi(self)
        self.cargar_categoria()
        
	self.show()
	self.set_signals()
	
    
    def cargar_categoria(self, recetas=None, paises=None):
	if recetas is None:
            recetas = controller.get_recetas()
            paises = controller.get_paises()
  
        #Creamos el modelo asociado a la tabla
        self.model = QtGui.QStandardItemModel(len(recetas),3)
        self.model.setHorizontalHeaderItem(0, QtGui.QStandardItem(u"Codigo"))
        self.model.setHorizontalHeaderItem(1, QtGui.QStandardItem(u"Recetas"))
        self.model.setHorizontalHeaderItem(2, QtGui.QStandardItem(u"Pais"))
        self.ui.table_categoria.setModel(self.model)
        self.ui.table_categoria.setColumnWidth(0,80)
        self.ui.table_categoria.setColumnWidth(1,210)
        self.ui.table_categoria.setColumnWidth(2,125)
        completer = QtGui.QCompleter(map(lambda c: c["nombre"], paises), self)
        completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        self.ui.search_box.setCompleter(completer)
        r = 0
        for row in recetas:
	    index = self.model.index(r, 0, QtCore.QModelIndex()); 
            self.model.setData(index, row['id_receta'])
            index = self.model.index(r, 1, QtCore.QModelIndex()); 
            self.model.setData(index, row['Nombre'])
            r = r+1
             
        i = 0
        for row in paises:
            index = self.model.index(i, 2, QtCore.QModelIndex()); 
            self.model.setData(index, row['Nombre'])
            i = i+1
            
    def set_signals(self):
        self.ui.button4.clicked.connect(self.delete)
        self.ui.button3.clicked.connect(self.v_formulario)
        self.ui.button1.clicked.connect(self.buscar_pais)
    
    
        
    def v_formulario(self):
	formu = ventana.Formu(self)
	
    def buscar_pais(self):
        pais = self.ui.search_box.text()
        paises = controller.buscar_pais(pais)
        self.cargar_categoria(paises)
  
   
        
    def delete(self):
        model = self.ui.table_categoria.model()
        index = self.ui.table_categoria.currentIndex()
        if index.row() == -1: #No se ha seleccionado una fila
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage("Debe seleccionar una fila")
            return False
        else:
            codigo = model.index(index.row(), 0, QtCore.QModelIndex()).data()
            ret = QtGui.QMessageBox.question(self, "Esta seguro?", "Esta seguro que desea eliminar?",
                        QtGui.QMessageBox.Ok | QtGui.QMessageBox.Cancel)		
            if (ret == QtGui.QMessageBox.Ok):
		if (controller.delete(codigo)):
                	self.cargar_categoria()
                	msgBox = QtGui.QMessageBox()
                	msgBox.setText("La receta fue eliminada.")
                	msgBox.exec_()
                	return True
            	else:
                	self.ui.errorMessageDialog = QtGui.QErrorMessage(self)
                	self.ui.errorMessageDialog.showMessage("Error al eliminar el registro")
                	return False	

  
	
def run():
    app = QtGui.QApplication(sys.argv)
    ma = main()
    sys.exit(app.exec_())

if __name__ == '__main__':
    run()
