# -*- coding: utf-8 -*-
import controller

from PySide import QtCore, QtGui

class Ui_Ventana(object):

    def setupUi(self, Window):
        Window.setObjectName("Window")
        Window.resize(750, 420)
        
        self.table_categoria= QtGui.QTableView(Window)
        self.table_categoria.setGeometry(QtCore.QRect(60,90,450,300))
        self.table_categoria.setObjectName("table_producto")
        self.table_categoria.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.table_categoria.setAlternatingRowColors(True)
        self.table_categoria.setSortingEnabled(True)
        
	#buscar
	self.button1= QtGui.QPushButton(Window)
        self.button1.setGeometry(QtCore.QRect(300,50,100,25))
        self.button1.setObjectName("button1")
       
        self.search_box = QtGui.QLineEdit(Window)
        self.search_box.setGeometry(QtCore.QRect(80, 50, 210, 25))
        self.search_box.setObjectName("search_box")
	
	self.button2 = QtGui.QPushButton(Window)
        self.button2.setGeometry(QtCore.QRect(560,120,130,50))
        self.button2.setObjectName("button2")
       
        self.button3 = QtGui.QPushButton(Window)
        self.button3.setGeometry(QtCore.QRect(560,190,130,50))
        self.button3.setObjectName("button3")
        
        #eliminar
        self.button4 = QtGui.QPushButton(Window)
        self.button4.setGeometry(QtCore.QRect(560,270,130,50))
        self.button4.setObjectName("button4")
        
        self.label = QtGui.QLabel(Window)
        self.label.setGeometry(QtCore.QRect(20,20,200,16))
        self.label.setObjectName("label")

        self.retranslateUi(Window)
        QtCore.QMetaObject.connectSlotsByName(Window)
        
        

    def retranslateUi(self, Window):
        Window.setWindowTitle(QtGui.QApplication.translate("Window", "Ventana", None, QtGui.QApplication.UnicodeUTF8))
        self.button1.setText(QtGui.QApplication.translate("Window", "Buscar", None, QtGui.QApplication.UnicodeUTF8))
	self.button2.setText(QtGui.QApplication.translate("Window", "Ver Receta", None, QtGui.QApplication.UnicodeUTF8))
	self.button3.setText(QtGui.QApplication.translate("Window", "Ingresar receta", None, QtGui.QApplication.UnicodeUTF8))
	self.button4.setText(QtGui.QApplication.translate("Window", "Eliminar receta", None, QtGui.QApplication.UnicodeUTF8))
	self.label.setText(QtGui.QApplication.translate("Window", "Recetas", None, QtGui.QApplication.UnicodeUTF8))
	self.search_box.setPlaceholderText(QtGui.QApplication.translate("Window", "Busque recetas por país aquí", None, QtGui.QApplication.UnicodeUTF8))
